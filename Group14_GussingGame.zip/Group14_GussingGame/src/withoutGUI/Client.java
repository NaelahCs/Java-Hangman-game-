package withoutGUI;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client {

    static int playerID;
    static Socket socket;
    static int score;
    static int attempts;
    static int opponentAttempts;
    static int winnerID;

    static DataInputStream fromServer;
    static DataOutputStream toServer;

    static boolean repeat = false;

    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) throws IOException {

        try {
            // CREATE A SOCKET TO CONNECT TO SERVER
            socket = new Socket("localhost", 8000);
            System.out.print("Connected! ");
        } catch (ConnectException e) {
            System.out.println("Server is not accepting connections "
                    + "\nbecause it is not running or stacked "
                    + "(Connection refused: connect)");
            System.exit(0);
        }// END TRY CATCH

        // I/O STREAM
        fromServer = new DataInputStream(socket.getInputStream());
        toServer = new DataOutputStream(socket.getOutputStream());

        // READ PLAYER ID FROM SERVER
        playerID = fromServer.readInt();
        // PRINT MESSAGE FROM SERVER
        System.out.println(fromServer.readUTF());

        do {

            // READ ATTEMPTS FROM SERVER
            opponentAttempts = attempts = fromServer.readInt();
           
            // SEND NUMBER OF ATTEMPTS TO GAME SERVER
            toServer.writeInt(attempts);

            // SEND SCORE TO GAME SERVER
            toServer.writeInt(score);

            System.out.println("num of attempts = " + attempts);

            // ------------------------- GAME -------------------------
            System.out.println("the game started..\n");

            // READ ENCRYPTED WORD FROM GAME SERVER
            System.out.println("\t " + fromServer.readUTF());

            while (winnerID == 0) {

                // IF BOTH PLAYERS ATTEMPTS HAS REACHED ZERO END ROUND
                if (attempts == 0 && opponentAttempts == 0) {
                    winnerID = -1; // EXIT FROM INNER LOOP
                    System.out.println(fromServer.readUTF());
                    continue;
                }// END LOOP

                // READ ID FROM GAME SERVER
                int turnOn = fromServer.readInt();

                if (turnOn == playerID) {

                    // READ NUM OF ATTEMPTS LEFT & SCORE
                    System.out.println(fromServer.readUTF());

                    System.out.print("it's your turn! guess a word or letter: ");
                    String guess = scan.nextLine().toLowerCase();

                    // SEND GUESSED WORD TO GAME SERVER
                    toServer.writeUTF(guess);

                    System.out.println(fromServer.readUTF());
                    attempts = fromServer.readInt();
                    opponentAttempts = fromServer.readInt();
                    System.out.println("------------------------------------\n");

                } else {

                    System.out.println("it's player " + turnOn + " turn!");
                    System.out.println(fromServer.readUTF());
                    attempts = fromServer.readInt();
                    opponentAttempts = fromServer.readInt();
                    System.out.println("------------------------------------\n");
                }// END IF ELSE

                winnerID = fromServer.readInt();

            }// END WHILE LOOP
            score = fromServer.readInt();
            System.out.println("Total Score = " + score);

            // PLAY ANOTHER GAME?
            System.out.print(fromServer.readUTF());
            String replay = scan.nextLine().toLowerCase();

            // SEND REPLAY ANSWER TO GAME SERVER
            toServer.writeUTF(replay);

            // UPDATE REPLAY
            repeat = fromServer.readBoolean();

            // UPDATE WINNER ID
            winnerID = 0;

        } while (repeat);

    }// END MAIN CLASS
}// END CLIENT CLASS
