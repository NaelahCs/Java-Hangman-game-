package withoutGUI;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Hangman extends Thread {

    // ---------------------------- DATA FIELDS ----------------------------
    static Socket player1;
    static Socket player2;

    static String player1Ans;
    static String player2Ans;

    static int player1Score;
    static int player2Score;
    
    static String player1Replay;
    static String player2Replay;

    static String Answer;
    static String encryptedWord;

    static int winner = 0;
    static int turnOn = 1; // FISRT START WITH PLAYER 1

    static DataInputStream fromPlayer1;
    static DataInputStream fromPlayer2;
    static DataOutputStream toPlayer1;
    static DataOutputStream toPlayer2;

    // ---------------------------- CONSTRUCTOR ----------------------------
    public Hangman(Socket player1, Socket player2, String word) {
        this.player1 = player1;
        this.player2 = player2;
        this.Answer = word;
        this.encryptedWord = encryptWord(Answer);
    }// END CONSTRUCTOR

    // ---------------------------- METHODS ----------------------------
    // ENCRYPTION (-,-,-,-,-)
    public static String encryptWord(String temp) {
        for (int i = 0; i < temp.length(); i++) {
            temp = temp.replace(temp.charAt(i), '-');
        }// END FOR LOOP
        System.out.println(temp);
        return temp;
    }// END METHOD

    // CHECK WORD OR LETTER
    public static boolean WordORLetter(String str) {
        if (str.length() > 1) {
            return true; // IT'S A WORD
        } else {
            return false; // IT'S A LETTER
        }// END IF ELSE
    }// END METHOD

    // COMPARE PLAYER'S GUESS WITH ANSWER
    public static boolean CheckAnswer(String str) {
        if (str.equalsIgnoreCase(Answer)) {
            encryptedWord = Answer;
            return true;
        }// END IF 
        return false;
    }// END METHOD

    // UPDATE ENCRYPTED WORD & RETURN TURE IF THRER IS CORRECT GUESS
    public static boolean printWordState(String str) {
        String temp = "";
        int correctCount = 0;
        for (int i = 0; i < Answer.length(); i++) {
            // IF LETTER WAS GUESS BEFORE
            if (encryptedWord.charAt(i) != '-') {
                temp += encryptedWord.charAt(i);

                // IF GUESSED LETTER IS CORRECT    
            } else if (Answer.charAt(i) == str.charAt(0)) {
                temp += Answer.charAt(i);
                correctCount++;
            } else {
                temp += "-";
            }// END IF ELSE
        }// END FOR LOOP

        // UPDATE ENCRYPTED WORD
        encryptedWord = temp;

        // RETURN TURE IF GUESS IS CORRECT
        return correctCount > 0;
    }// END METHOD
    
    public static Boolean replayGame() throws IOException {

        // ASK PLAYERS IF THEY WANNA PLAY AGAIN
        toPlayer1.writeUTF("Start Another Hangman Game? (y/n) ");
        toPlayer2.writeUTF("Start Another Hangman Game? (y/n) ");

        player1Replay = fromPlayer1.readUTF();
        player2Replay = fromPlayer2.readUTF();

        // CHECK IF BOTH PLAYERS ENTERED YES "Y"
        if (player1Replay.equalsIgnoreCase(player2Replay) && player1Replay.equalsIgnoreCase("Y")) {
            // REPLAY GAME
            return true;
        }// END IF 
        return false;
    }// END METHOD

    @Override
    public void run() {
        try {
            // I/O STREAM
            fromPlayer1 = new DataInputStream(player1.getInputStream());
            fromPlayer2 = new DataInputStream(player2.getInputStream());
            toPlayer1 = new DataOutputStream(player1.getOutputStream());
            toPlayer2 = new DataOutputStream(player2.getOutputStream());

            // READ NUMBER OF ATTEMPTS FROM PLAYERS
            int Player1attempts = fromPlayer1.readInt();
            int Player2attempts = fromPlayer2.readInt();

            // READ SCORES FROM PLAYERS
            int player1Score = fromPlayer1.readInt();
            int player2Score = fromPlayer2.readInt();

            // PRINT ENCRYPTER WORD TO PLAYERS
            toPlayer1.writeUTF(encryptedWord);
            toPlayer2.writeUTF(encryptedWord);

            // WHILE STILL THERE IS NO WINNER YET CONTINUE
            while (winner == 0) {
                
                
                // IF BOTH PLAYERS ATTEMPTS HAS REACHED ZERO END ROUND
                if (Player1attempts == 0 && Player2attempts == 0) {
                    // SEND MESSAGE TO PLAYER 1 & 2
                    toPlayer1.writeUTF("both players lose the game\nthe word is " + Answer);
                    toPlayer2.writeUTF("both players lose the game\nthe word is " + Answer);
                    break;
                }// END IF
                
                // SEND PLAYER ID
                toPlayer1.writeInt(turnOn);
                toPlayer2.writeInt(turnOn);

                // ---------------------------- PLAYER 1 ---------------------------- 
                if (turnOn == 1) {

                    // IF PLAYER 1 NUMBER OF ATTEMPTS HAS REACHED ZERO
                    if (Player1attempts == 0) {
                        
                        turnOn = 2;
                        continue;

                    } else {

                        // SEND NUMBER OF ATTEMPS & TOTAL SCORE
                        toPlayer1.writeUTF("Number of attempts left = "
                                + Player1attempts + "\nYour Current score = " + player1Score);

                        // READ GUESSED WORD FROM PLAYER 1
                        player1Ans = fromPlayer1.readUTF();

                        // IF PLAYER'S GUESS IS A WORD 
                        if (WordORLetter(player1Ans)) {

                            // ---------------------- CASE 1 ----------------------
                            // 1. GUESS A WORD AND WIN 
                            // CHECK IF PLAYER'S GUESS IS CORRECT
                            if (CheckAnswer(player1Ans)) {

                                // SEND MESSAGE TO PLAYER 1 & 2
                                toPlayer1.writeUTF("\t" + encryptedWord 
                                        + "\nyou're guess is right! you win the game!\n");
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                toPlayer2.writeUTF("\t" + encryptedWord 
                                        + "\n Game over, player 1 wins the game\n");
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                // INCREMENT SCORE
                                player1Score += 10;
                                winner = 1;

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                continue;

                                // ELSE PLAYER'S GUESS IS INCORRECT
                            } else {

                                // DECREMENT ATTEMPT
                                Player1attempts--;
                                
                                // SEND MESSAGE TO PLAYER 1 & 2
                                if (Player1attempts == 0) {
                                    toPlayer1.writeUTF("\t" + encryptedWord 
                                            + "\nGame Over\n");
                                } else {
                                    toPlayer1.writeUTF("\t" + encryptedWord 
                                            + "\nyou're guess is wrong!\n");
                                }// END IF ELSE
                                
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);
                                
                                toPlayer2.writeUTF("\t" + encryptedWord);
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 2;
                                continue;

                            }// END IF ELSE (CASE 1)

                            // IF PLAYER'S GUESS IS A LETTER
                        } else {

                            // IF PLAYER'S GUESS IS CORRECT
                            if (printWordState(player1Ans)) {

                                // ---------------------- CASE 2 ----------------------
                                // 2. GUESS A LETTER AND WIN
                                // IF PLAYER GUESS WHOLE WORD
                                if (CheckAnswer(encryptedWord)) {

                                    // SEND MESSAGE TO PLAYER 1 & 2
                                    toPlayer1.writeUTF("\t" + encryptedWord + "\nyou're guess is right! you win the game!\n");
                                    toPlayer1.writeInt(Player1attempts);
                                    toPlayer1.writeInt(Player2attempts);

                                    toPlayer2.writeUTF("\t" + encryptedWord + "\n Game over, player 1 wins the game\n");
                                    toPlayer2.writeInt(Player2attempts);
                                    toPlayer2.writeInt(Player1attempts);

                                    // INCREMENT SCORE
                                    player1Score += 10;
                                    winner = 1;

                                    // SEND WINNER ID TO PLAYERS
                                    toPlayer1.writeInt(winner);
                                    toPlayer2.writeInt(winner);

                                    continue;
                                }// END IF (CASE 2)

                                // ---------------------- CASE 3 ----------------------
                                // 3. GUESS A LETTER CORRECTLY BUT DIDN'T WIN
                                // SEND MESSAGE TO PLAYER 1 & 2
                                toPlayer1.writeUTF("\t" + encryptedWord + "\nyou're guess is right!\n");
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                toPlayer2.writeUTF("\t" + encryptedWord);
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 2;
                                continue;

                                // ---------------------- CASE 4 ----------------------
                                // 4. GUESS A LETTER AND LOSE
                            } else {
                                
                                // DECREMENT ATTEMPT
                                Player1attempts--;
                                
                                // SEND MESSAGE TO PLAYER 1 & 2
                                if (Player1attempts == 0) {
                                    toPlayer1.writeUTF("\t" + encryptedWord + "\nGame Over\n");
                                } else {
                                    toPlayer1.writeUTF("\t" + encryptedWord + "\nyou're guess is wrong!\n");
                                }// END IF ELSE
                                
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                toPlayer2.writeUTF("\t" + encryptedWord);
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 2;
                                continue;

                            }// END IF ELSE.. (CASE 3 & 4)
                        }// END IF ELSE.. IT'S A WORD
                    }// END IF ELSE.. PLAYER ATTEMPT EQUALS ZERO?
                }// END IF (PLAYER 1)

                // ---------------------------- PLAYER 2 ----------------------------
                if (turnOn == 2) {

                    // IF PLAYER 2 NUMBER OF ATTEMPTS HAS REACHED ZERO
                    if (Player2attempts == 0) {
                        
                        turnOn = 1;
                        continue;

                    } else {

                        // SEND NUMBER OF ATTEMPS & TOTAL SCORE
                        toPlayer2.writeUTF("Number of attempts left = "
                                + Player2attempts + "\nYour Current score = " + player2Score);

                        // READ GUESSED WORD FROM PLAYER 2
                        player2Ans = fromPlayer2.readUTF();

                        // IF PLAYER'S GUESS IS A WORD 
                        if (WordORLetter(player2Ans)) {

                            // ---------------------- CASE 1 ----------------------
                            // 1. GUESS A WORD AND WIN 
                            // CHECK IF PLAYER'S GUESS IS CORRECT
                            if (CheckAnswer(player2Ans)) {

                                // SEND MESSAGE TO PLAYER 1 & 2
                                toPlayer2.writeUTF("\t" + encryptedWord + "\nyou're guess is right! you win the game!\n");
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                toPlayer1.writeUTF("\t" + encryptedWord + "\n Game over, player 2 wins the game\n");
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                // INCREMENT SCORE
                                player2Score += 10;
                                winner = 2;

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                continue;

                                // ELSE PLAYER'S GUESS IS INCORRECT
                            } else {
                                
                                // DECREMENT ATTEMPT
                                Player2attempts--;
                                
                                // SEND MESSAGE TO PLAYER 1 & 2
                                if (Player2attempts == 0) {
                                    toPlayer2.writeUTF("\t" + encryptedWord + "\nGame Over\n");
                                } else {
                                    toPlayer2.writeUTF("\t" + encryptedWord + "\nyou're guess is wrong!\n");
                                }// END IF ELSE
                                
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                toPlayer1.writeUTF("\t" + encryptedWord);
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 1;
                                continue;

                            }// END IF ELSE (CASE 1)

                            // IF PLAYER'S GUESS IS A LETTER
                        } else {

                            // IF PLAYER'S GUESS IS CORRECT
                            if (printWordState(player2Ans)) {

                                // ---------------------- CASE 2 ----------------------
                                // 2. GUESS A LETTER AND WIN
                                // IF PLAYER GUESS WHOLE WORD
                                if (CheckAnswer(encryptedWord)) {

                                    // SEND MESSAGE TO PLAYER 1 & 2
                                    toPlayer2.writeUTF("\t" + encryptedWord + "\nyou're guess is right! you win the game!\n");
                                    toPlayer2.writeInt(Player2attempts);
                                    toPlayer2.writeInt(Player1attempts);

                                    toPlayer1.writeUTF("\t" + encryptedWord + "\n Game over, player 2 wins the game\n");
                                    toPlayer1.writeInt(Player1attempts);
                                    toPlayer1.writeInt(Player2attempts);

                                    // INCREMENT SCORE
                                    player2Score += 10;
                                    winner = 2;

                                    // SEND WINNER ID TO PLAYERS
                                    toPlayer1.writeInt(winner);
                                    toPlayer2.writeInt(winner);

                                    continue;
                                }// END IF (CASE 2)

                                // ---------------------- CASE 3 ----------------------
                                // 3. GUESS A LETTER CORRECTLY BUT DIDN'T WIN
                                // SEND MESSAGE TO PLAYER 1 & 2
                                toPlayer2.writeUTF("\t" + encryptedWord + "\nyou're guess is right!\n");
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                toPlayer1.writeUTF("\t" + encryptedWord);
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 1;
                                continue;

                                // ---------------------- CASE 4 ----------------------
                                // 4. GUESS A LETTER AND LOSE
                            } else {
                                
                                // DECREMENT ATTEMPT
                                Player2attempts--;
                                
                                // SEND MESSAGE TO PLAYER 1 & 2
                                if (Player2attempts == 0) {
                                    toPlayer2.writeUTF("\t" + encryptedWord + "\nGame Over\n");
                                } else {
                                    toPlayer2.writeUTF("\t" + encryptedWord + "\nyou're guess is wrong!\n");
                                }// END IF ELSE
                                
                                toPlayer2.writeInt(Player2attempts);
                                toPlayer2.writeInt(Player1attempts);

                                toPlayer1.writeUTF("\t" + encryptedWord);
                                toPlayer1.writeInt(Player1attempts);
                                toPlayer1.writeInt(Player2attempts);

                                
                                // SEND WINNER ID TO PLAYERS
                                toPlayer1.writeInt(winner);
                                toPlayer2.writeInt(winner);

                                turnOn = 1;
                                continue;
                            }// END IF ELSE.. (CASE 3 & 4)
                        }// END IF ELSE.. IT'S A WORD
                    }// END IF ELSE.. PLAYER ATTEMPT EQUALS ZERO?
                }// END IF (PLAYER 2)
            }// END WHILE LOOP
            
            // UPDATE WINNER ID
            winner = 0;
            
            // SEND TOTAL SCORE TO PLAYERS
            toPlayer1.writeInt(player1Score);
            toPlayer2.writeInt(player2Score);
            
        } catch (IOException ex) {
            Logger.getLogger(Hangman.class.getName()).log(Level.SEVERE, null, ex);
        }// END TRY CATCH
    }// END RUN METHOD
    
}// END CLASS

