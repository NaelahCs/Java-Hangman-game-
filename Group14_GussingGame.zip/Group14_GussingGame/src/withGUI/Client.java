package withGUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Client implements ActionListener {

    static int playerID;
    static Socket socket;
    static int score;
    static int attempts;
    static int opponentAttempts;
    static int winnerID;

    static DataInputStream fromServer;
    static DataOutputStream toServer;

    static boolean repeat = false;

    static Scanner scan = new Scanner(System.in);

    static playingForm GUI = new playingForm();

    static ImageIcon pic = new ImageIcon();

    public static void main(String[] args) throws IOException {

        Client player = new Client();

        GUI.setVisible(true);
        GUI.setLocationRelativeTo(null);
        GUI.jButton1.setEnabled(false);
        GUI.enter.setEditable(false);

        try {
            // CREATE A SOCKET TO CONNECT TO SERVER
            socket = new Socket("localhost", 8000);
            GUI.message.setText("Connected! ");

        } catch (ConnectException e) {
            GUI.message.setText("Server is not accepting connections "
                    + "\nbecause it is not running or stacked "
                    + "(Connection refused: connect)");
            System.exit(0);
        }// END TRY CATCH// END TRY CATCH

        // I/O STREAM
        fromServer = new DataInputStream(socket.getInputStream());
        toServer = new DataOutputStream(socket.getOutputStream());

        // READ PLAYER ID FROM SERVER
        playerID = fromServer.readInt();
        // PRINT MESSAGE FROM SERVER
        GUI.message.setText(fromServer.readUTF());

        do {

            // READ ATTEMPTS FROM SERVER
            opponentAttempts = attempts = 10;

            // SEND NUMBER OF ATTEMPTS TO GAME SERVER
            toServer.writeInt(attempts);

            // SEND SCORE TO GAME SERVER
            toServer.writeInt(score);

            GUI.Attempt.setText("Attempts = " + attempts);

            // ------------------------- GAME -------------------------
            GUI.message.setText("the game started..\n");

            // READ ENCRYPTED WORD FROM GAME SERVER
            GUI.encryptedWord.setText(fromServer.readUTF());

            while (winnerID == 0) {

                GUI.jButton1.setEnabled(false);
                GUI.enter.setEditable(false);

                // IF BOTH PLAYERS ATTEMPTS HAS REACHED ZERO END ROUND
                if (attempts == 0 && opponentAttempts == 0) {
                    winnerID = -1; // EXIT FROM INNER LOOP
                    GUI.message.setText(fromServer.readUTF());
                    continue;
                }// END LOOP

                // READ ID FROM GAME SERVER
                int turnOn = fromServer.readInt();

                if (turnOn == playerID) {

                    GUI.jButton1.setEnabled(true);
                    GUI.enter.setEditable(true);

                    // READ NUM OF ATTEMPTS LEFT & SCORE
                    attempts = fromServer.readInt();
                    GUI.Attempt.setText("Attempts = " + attempts);

                    score = fromServer.readInt();
                    GUI.score.setText("Score = " + score);

                    GUI.message.setText("it's your turn!");

                    GUI.jButton1.addActionListener(player);
                    GUI.enter.setText("");

                    // UPDATE ENCRYPTED WORD
                    GUI.encryptedWord.setText(fromServer.readUTF()); // READ ENCRYPTED WORD
                    GUI.message.setText(fromServer.readUTF()); // READ MESSAGE 

                    // UPDATE NUM OF ATTEMPTS
                    attempts = fromServer.readInt();
                    GUI.Attempt.setText("Attempts = " + attempts);

                    opponentAttempts = fromServer.readInt();

                } else {

                    GUI.message.setText("it's player " + turnOn + " turn!");

                    // UPDATE ENCRYPTED WORD
                    GUI.encryptedWord.setText(fromServer.readUTF());
                    GUI.message.setText(fromServer.readUTF());

                    // UPDATE NUM OF ATTEMPTS
                    attempts = fromServer.readInt();
                    GUI.Attempt.setText("Attempts = " + attempts);

                    opponentAttempts = fromServer.readInt();
                }// END IF ELSE

                winnerID = fromServer.readInt();

            }// END WHILE LOOP
            score = fromServer.readInt();
            GUI.score.setText("Score = " + score);

            GUI.jButton1.setEnabled(true);
            GUI.enter.setEditable(true);

            // PLAY ANOTHER GAME?
            //GUI.message.setText(fromServer.readUTF());
            GUI.message.setText("Start Another Hangman Game? (y/n) ");

            GUI.jButton1.addActionListener(player);
            GUI.enter.setText("");

            // SEND REPLAY ANSWER TO GAME SERVER
            //toServer.writeUTF(replay);
            // UPDATE REPLAY
            repeat = fromServer.readBoolean();

            if (repeat) {
                GUI.message.setText("Starting another game..");
            } else {
                GUI.message.setText("End game.. ");
                GUI.jButton1.setEnabled(false);
                GUI.enter.setEditable(false);

            }

            // UPDATE WINNER ID
            winnerID = 0;

        } while (repeat);

        System.exit(0);

    }// END MAIN CLASS

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == GUI.jButton1) {
            try {
                String temp = GUI.enter.getText().toLowerCase();
                // SEND GUESSED WORD TO GAME SERVER
                toServer.writeUTF(temp);

            } catch (IOException ex) {
                //Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void picture(int attempt) {

        GUI.pic = new JLabel(pic);

        try {
            if (attempt == 10) {
                GUI.pic.setIcon(new ImageIcon("introPic.jpeg"));

            } else if (attempt == 9) {
                GUI.pic.setIcon(new ImageIcon("pop1.jpg"));
                GUI.pic.setIcon((new ImageIcon("2Bpop.jpg")));
            } else if (attempt == 8) {
                GUI.pic.setIcon((new ImageIcon("pop2.jpg")));
                GUI.pic.setIcon(new ImageIcon("3Bpop.jpg"));
            } else if (attempt == 7) {
                GUI.pic.setIcon(new ImageIcon("pop3.jpg"));
                GUI.pic.setIcon(new ImageIcon("4Bpop.jpg"));
            } else if (attempt == 6) {
                GUI.pic.setIcon(new ImageIcon("pop4.jpg"));
                GUI.pic.setIcon(new ImageIcon("5Bpop.jpg"));
            } else if (attempt == 5) {
                GUI.pic.setIcon(new ImageIcon("pop5.jpg"));
                GUI.pic.setIcon(new ImageIcon("6Bpop.jpg"));
            } else if (attempt == 4) {
                GUI.pic.setIcon(new ImageIcon("pop6.jpg"));
                GUI.pic.setIcon(new ImageIcon("7Bpop.jpg"));
            } else if (attempt == 3) {
                GUI.pic.setIcon(new ImageIcon("pop7.jpg"));
                GUI.pic.setIcon(new ImageIcon("8Bpop.jpg"));

            } else if (attempt == 2) {
                GUI.pic.setIcon(new ImageIcon("pop8.jpg"));
                GUI.pic.setIcon(new ImageIcon("9Bpop.jpg"));
            } else if (attempt == 1) {
                GUI.pic.setIcon(new ImageIcon("pop9.jpg"));
                GUI.pic.setIcon(new ImageIcon("10Bpop.jpg"));
            } else if (attempt == 0) {
                GUI.pic.setIcon(new ImageIcon("pop10.jpg"));
                GUI.pic.setIcon(new ImageIcon("gameOver.jpg"));
            }

        } catch (Exception e) {
            System.out.println("image not found");
        }

    }

}// END CLIENT CLASS
