package withGUI;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/* 
 * THE SERVER APPLICATION MANAGES THE GUESSING GAME, 
 * SELECT A WORD FROM THE DICTIONARY, 
 * AND HANDLES MULTIPLE PLAYERS BY CREATING A SESSION 
 * FOR EVERY TWO PLAYERS WHO ARE GOING TO GUESS THE WORD. 
 */
public class Server {

    static Socket Player1;
    static Socket Player2;
    
    
    static DataInputStream fromPlayer1;
    static DataInputStream fromPlayer2;
    static DataOutputStream toPlayer1;
    static DataOutputStream toPlayer2;
    
    static String player1Replay;
    static String player2Replay;

    
    static boolean replay = false;

    public static void main(String[] args) throws IOException {

        
         page page = new page();
        page.setVisible(true);
        page.setLocationRelativeTo(null);
        for (int i = 0; i <= 100; i++) {
            try {
                Thread.sleep(50);
                page.num.setText(Integer.toString(i) + "%");
                page.bar.setValue(i);
                if (i == 100) {
                    page.setVisible(false);
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }

        }// LOADING PAGE
        
        // CREATING TCP SERVER SOCKET
        ServerSocket server = new ServerSocket(8000);
        System.out.println("Hangman Game Server Started ...\nWaiting for player 1 to join...");

        // SERVER ACCEPT CLIENT'S CONNECTION REQUEST:
        // ---------------------- PLAYER 1 ----------------------
        // CREATING SOCKET 
        Player1 = server.accept();
        
        // I/O STREAM
        fromPlayer1 = new DataInputStream(Player1.getInputStream());
        toPlayer1 = new DataOutputStream(Player1.getOutputStream());

        // SEND PLAYER ID
        toPlayer1.writeInt(1);
        
        System.out.println("\t>>Player 1 joind the game\n\nWaiting for player 2 to join...");
        new DataOutputStream(Player1.getOutputStream()).writeUTF("You're Player No. 1 \nWaiting for player 2 to join...");

        // ---------------------- PLAYER 2 ----------------------
        // CREATING SOCKET 
        Player2 = server.accept();
        
        // I/O STREAM
        fromPlayer2 = new DataInputStream(Player2.getInputStream());
        toPlayer2 = new DataOutputStream(Player2.getOutputStream());
        
        // SEND PLAYER ID
        toPlayer2.writeInt(2);
        
        System.out.println("\t>>Player 2 joind the game");
        new DataOutputStream(Player2.getOutputStream()).writeUTF("You're Player No. 2 \n");

        do {
            // SELECT A WORD FROM THE DICTIONARY
            String answer = chooseWord((new File("words.txt")));
            System.out.println(answer);

            // START GAME
            Hangman game = new Hangman(Player1, Player2, answer);
            game.run();
           
            // UPDATE REPLAY
            replay = Hangman.replayGame();
            
            toPlayer1.writeBoolean(replay);
            toPlayer2.writeBoolean(replay);
            
        } while (replay);
        
        System.exit(0);
        
    }// END MAIN CLASS

    // SELECT A WORD FROM THE DICTIONARY
    public static String chooseWord(File file) throws IOException {
        
        // GENERATE A RANDOM LINE
        int random = (int)(Math.random() * 50) + 1;
        System.out.println(random);
        
        // RETUN A WORD IN SPECIFIC LINE
        String str = Files.readAllLines(Paths.get(file.getPath())).get(random);
        
        return str;
    }// END METHOD

}// END SERVER CLASS
